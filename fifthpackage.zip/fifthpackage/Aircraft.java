// -----------------------------------------------------
// Assignment 1
// Part: 1
// Written by: (include your name(s) and student ID(s))
// -----------------------------------------------------
package fifthpackage;

public class Aircraft{

    protected double price;
    protected double maximumElevation;
    protected long serialNumber;
    private static long nextAircraftSerialNumber = 0L;

    public Aircraft(){
    	this.serialNumber = Aircraft.getNextAircraftSerialNumber();
    }

    public Aircraft(double pr, double maxElev){

        this.price = pr;
        this.maximumElevation = maxElev;
        this.serialNumber = Aircraft.getNextAircraftSerialNumber();
    }

    public Aircraft(Aircraft rc){
        price = rc.price;
        maximumElevation = rc.maximumElevation;
        this.serialNumber = Aircraft.getNextAircraftSerialNumber();
    }

    public static long getNextAircraftSerialNumber(){
        return nextAircraftSerialNumber++;
    }

    public void setSerialNumber(long serialNumber){
        this.serialNumber = serialNumber;
    }

    public double getPrice(){
        return price;
    }

    public double getMaximumElevation(){
        return maximumElevation;
    }


    public void setPrice(double pr){
        this.price = pr;
    }

    public void setMaximumElevation(double maximumElev){
        this.maximumElevation = maximumElev;
    }

    public String toString(){
        return "This Aircraft - serial#" + this.serialNumber + " - has a price of $" + price + ". It has a maximum elevation of " + maximumElevation + " ft.";
    }

    public boolean equals(Object obj) {
        // Check if the object being compared is null
        if (obj == null) {
            return false;
        }
    
        // Check if the object being compared is of a different type than the calling object
        if (getClass() != obj.getClass()) {
            return false;
        }
    
        // Cast the object to an Aircraft
        Aircraft otherAircraft = (Aircraft) obj;
    
        // Compare attributes (price and maximumElevation)
        return Double.compare(getPrice(), otherAircraft.getPrice()) == 0 &&
               Double.compare(getMaximumElevation(), otherAircraft.getMaximumElevation()) == 0;
    }

}