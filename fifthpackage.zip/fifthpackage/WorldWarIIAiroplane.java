// -----------------------------------------------------
// Assignment 1
// Part: 1
// Written by: (include your name(s) and student ID(s))
// -----------------------------------------------------
package fifthpackage;

public class WorldWarIIAiroplane extends Aircraft {

    private boolean twinEngine;
    private static long nextWW2AirplaneSerialNumber = 80000L;

    public WorldWarIIAiroplane() {
        super();
        this.twinEngine = false;
        this.serialNumber = WorldWarIIAiroplane.getNextWW2AirplaneSerialNumber();
        
    }

    public WorldWarIIAiroplane(boolean twinEng, double pr, double maxElev) {
        super(pr, maxElev);
        this.twinEngine = twinEng;
        this.serialNumber = WorldWarIIAiroplane.getNextWW2AirplaneSerialNumber();
    }

    public WorldWarIIAiroplane(WorldWarIIAiroplane wwPlane) {
        super(wwPlane);
        this.twinEngine = wwPlane.twinEngine;
        this.serialNumber = WorldWarIIAiroplane.getNextWW2AirplaneSerialNumber();
    }

    public static long getNextWW2AirplaneSerialNumber() {
        return nextWW2AirplaneSerialNumber++;
    }

    public boolean getTwinEngine() {
        return twinEngine;
    }

    public void setTwinEngine(boolean twinEng) {
        this.twinEngine = twinEng;
    }

    @Override
    public String toString() {
        String engineType = twinEngine ? "twin engine" : "single engine";
        return "World War II Airplane - serial #" + this.serialNumber + " - has a " +
        engineType + ", price of the plane is $" + price + ". The maximum elevation of the plane is " + maximumElevation + " ft.";
    }

    public boolean equals(Object obj) {
        // Check if the object being compared is the same as the calling object
        if (this == obj) {
            return true;
        }
    
        // Check if the object being compared is null
        if (obj == null) {
            return false;
        }
    
        // Check if the object being compared is of a different type than the calling object
        if (getClass() != obj.getClass()) {
            return false;
        }
    
        // Cast the object to a WorldWarIIAiroplane
        WorldWarIIAiroplane otherAirplane = (WorldWarIIAiroplane) obj;
    
        // Compare attributes (twinEngine, price, and maximumElevation)
        return twinEngine == otherAirplane.twinEngine &&
               Double.compare(getPrice(), otherAirplane.getPrice()) == 0 &&
               Double.compare(getMaximumElevation(), otherAirplane.getMaximumElevation()) == 0;
    }

}