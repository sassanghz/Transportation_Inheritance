// -----------------------------------------------------
// Assignment 1
// Part: 1
// Written by: (include your name(s) and student ID(s))
// -----------------------------------------------------
package secondpackage;

import java.util.Objects;

import firstpackage.WheeledTransportation;

public class Train extends WheeledTransportation {

    private static long nextTrainSerialNumber = 10000L;

    protected int numOfVehicles;
    protected String startingStation;
    protected String destinationStation;

    // Default Constructor
    public Train() {
        super();
        this.numOfVehicles = 0;
        this.startingStation = "";
        this.destinationStation = "";
        this.serialNumber = Train.getNextTrainSerialNumber();
    
    }

    public Train(int numOfWheels, double maxSpeed, int numOfVehicles, String startingStation, String destinationStation) {
        super(numOfWheels, maxSpeed);
        this.numOfVehicles = numOfVehicles;
        this.startingStation = startingStation;
        this.destinationStation = destinationStation;
        this.serialNumber = Train.getNextTrainSerialNumber();
    }

    public Train(Train other) {
        super(other);
        this.numOfVehicles = other.numOfVehicles;
        this.startingStation = other.startingStation;
        this.destinationStation = other.destinationStation;
        this.serialNumber = Train.getNextTrainSerialNumber();
    }

    // Getter methods

    public int getNumOfVehicles() { // Corrected the method name
        return numOfVehicles;
    }

    public String getStartingStation() {
        return startingStation;
    }

    public String getDestinationStation() {
        return destinationStation;
    }

    public static long getNextTrainSerialNumber() {
        return nextTrainSerialNumber++;
    }

    public void setNumOfVehicles(int numOfVehicles) { // Corrected the method name
        this.numOfVehicles = numOfVehicles;
    }

    public void setStartingStation(String startingStation) {
        this.startingStation = startingStation;
    }

    public void setDestinationStation(String destinationStation) {
        this.destinationStation = destinationStation;
    }

    public String toString(){
        
        return "This Train - serial #" + this.serialNumber + "- has " + numOfWheels + " wheels, has a maximum speed of " +
        maxSpeed + " km/hr. It has " + numOfVehicles + " vehicles and its starting and destination stations are " +
        startingStation + " and " + destinationStation;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true; // Same object reference, they are equal
        }
    
        if (obj == null || getClass() != obj.getClass()) {
            return false; // Object is null or of a different class, they are not equal
        }
    
        Train otherTrain = (Train) obj;
        
        // Use Objects.equals to compare attributes, it handles null values
        return Objects.equals(getNumOfWheels(), otherTrain.getNumOfWheels()) &&
               Objects.equals(getMaxSpeed(), otherTrain.getMaxSpeed()) &&
               Objects.equals(getNumOfVehicles(), otherTrain.getNumOfVehicles()) &&
               Objects.equals(getStartingStation(), otherTrain.getStartingStation()) &&
               Objects.equals(getDestinationStation(), otherTrain.getDestinationStation());
    }

}