// -----------------------------------------------------
// Assignment 1
// Part: 1
// Written by: (include your name(s) and student ID(s))
// -----------------------------------------------------
package secondpackage;

import java.util.Objects;

import thirdpackage.Metro;

public class Tram extends Metro{
    
    private static long nextTramSerialNumber = 300000L;
    protected int yearOfCreation;

    public Tram(){
        super();
        this.yearOfCreation = 2001;
        this.serialNumber = Tram.getNextTrainSerialNumber();
    }

    public Tram(int yearOfCreation, int numOfVehicles, String startingStation, String destinationStation, int totalNumberOfStops, double maxSpeed, int numOfWheels){
        super(numOfVehicles, startingStation, destinationStation, totalNumberOfStops, maxSpeed, numOfWheels);
        this.yearOfCreation = yearOfCreation;
        this.serialNumber = Tram.getNextTrainSerialNumber();
    }

    public Tram(Tram tr){
        yearOfCreation = tr.yearOfCreation;
        setDestinationStation(tr.getDestinationStation());
        setMaxSpeed(tr.getMaxSpeed());
        setNumOfWheels(tr.getNumOfWheels());
        setNumOfVehicles(tr.getNumOfVehicles());
        setStartingStation(tr.getStartingStation());
        setTotalNumOfStops(tr.getTotalNumOfStops());
        this.serialNumber = Tram.getNextTrainSerialNumber();
    }

    public int getYearOfCreation(){
        return yearOfCreation;
    }

    public static long getNextTramSerialNumber(){
        return nextTramSerialNumber++;
    }

    public void setYearOfCreation(int yearOfCreation){
        this.yearOfCreation = yearOfCreation;
    }

    public String toString(){
        return "This Tram - serial #" + this.serialNumber + " - has " + numOfWheels + " wheels, has a maximum speed of " + maxSpeed + 
        " km/hr. It has " + numOfVehicles + " vehicles and its starting and destination stations are " +
        startingStation + " and " + destinationStation + ". The total number of stops is " + totalNumOfStops + ". The year of creation is " + yearOfCreation;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true; // Same object reference, they are equal
        }
    
        if (obj == null || getClass() != obj.getClass()) {
            return false; // Object is null or of a different class, they are not equal
        }
    
        Tram otherTram = (Tram) obj;
    
        // Compare attributes, excluding the serial number
        return Objects.equals(getNumOfWheels(), otherTram.getNumOfWheels()) &&
               Objects.equals(getMaxSpeed(), otherTram.getMaxSpeed()) &&
               Objects.equals(getNumOfVehicles(), otherTram.getNumOfVehicles()) &&
               Objects.equals(getStartingStation(), otherTram.getStartingStation()) &&
               Objects.equals(getDestinationStation(), otherTram.getDestinationStation()) &&
               Objects.equals(getTotalNumOfStops(), otherTram.getTotalNumOfStops()) &&
               getYearOfCreation() == otherTram.getYearOfCreation();
    }


}