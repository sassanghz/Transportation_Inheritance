// -----------------------------------------------------
// Assignment 1
// Part: 1
// Written by: (include your name(s) and student ID(s))
// -----------------------------------------------------
package thirdpackage;

import java.util.Objects;

import secondpackage.Train;
import secondpackage.Tram;

public class Metro extends Train{

    protected int totalNumOfStops;
    private static long nextMetroSerialNumber = 25000L;

    public Metro(){
        super();
        this.totalNumOfStops = 1;
        this.serialNumber = Metro.getNextTrainSerialNumber();
    }

    public Metro(int numOfVehicles, String startingStation, String destinationStation, int totalNumberOfStops, double maxSpeed, int numOfWheels) {
        super(numOfVehicles, maxSpeed, totalNumberOfStops, startingStation, destinationStation);
        this.totalNumOfStops = totalNumberOfStops;
        this.serialNumber = Metro.getNextTrainSerialNumber();
    }

    public Metro(Metro met){
        totalNumOfStops = met.totalNumOfStops;
        setDestinationStation(met.getDestinationStation());
        setMaxSpeed(met.getMaxSpeed());
        setNumOfWheels(met.getNumOfWheels());
        setNumOfVehicles(met.getNumOfVehicles());
        setStartingStation(met.getStartingStation());
        this.serialNumber = Metro.getNextTrainSerialNumber();
    }

    

    public int getTotalNumOfStops(){
        return totalNumOfStops;
    }

    public void setTotalNumOfStops(int totalNumberOfStops){
        this.totalNumOfStops = totalNumberOfStops;
    }

    public static long getNextMetroSerialNumber(){
        return nextMetroSerialNumber++;
    }

    public String toString(){
        return "This Metro - serial #" + this.serialNumber + " - has " + numOfWheels + " wheels, has a maximum speed of " + maxSpeed + 
        " km/hr. It has " + numOfVehicles + " vehicles and its starting and destination stations are " +
        startingStation + " and " + destinationStation + ". The total number of stops is " + totalNumOfStops;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true; // Same object reference, they are equal
        }
    
        if (obj == null || getClass() != obj.getClass()) {
            return false; // Object is null or of a different class, they are not equal
        }
    
        Metro otherMetro = (Metro) obj;
        
        // Compare attributes, excluding the serial number
        return Objects.equals(getNumOfWheels(), otherMetro.getNumOfWheels()) &&
               Objects.equals(getMaxSpeed(), otherMetro.getMaxSpeed()) &&
               Objects.equals(getNumOfVehicles(), otherMetro.getNumOfVehicles()) &&
               Objects.equals(getStartingStation(), otherMetro.getStartingStation()) &&
               Objects.equals(getDestinationStation(), otherMetro.getDestinationStation()) &&
               Objects.equals(getTotalNumOfStops(), otherMetro.getTotalNumOfStops());
    }

    
}