import fifthpackage.Aircraft;
import fifthpackage.WorldWarIIAiroplane;
import firstpackage.WheeledTransportation;
import fourthpackage.Monowheel;
import secondpackage.Train;
import secondpackage.Tram;
import sixthpackage.Ferry;
import thirdpackage.Metro;
import java.util.Arrays;


public class Driver_Part2{
      

        public static Object[] copyTheObjects(Object[] arrayDriver){

        	Object[] copyArr = new Object[arrayDriver.length];

            for(int i = 0; i < copyArr.length; i++){
            	copyArr[i] = new Object();
            }
            return copyArr;

        }

        public static void displayInventoryInfo(Object[] arrayDriver){
            String firstClass;

            System.out.println("Here is the information of the transportation in that inventory.");
            for(int i = 0; i < arrayDriver.length; i++){
                firstClass = arrayDriver[i].getClass().toString();
                System.out.println((i+1) + ". " + firstClass);
            }
        }

    

    public static void main(String[] args){

        Object[] objects = new Object[16];
        objects[0] = new WheeledTransportation(20, 45000);
        objects[1] = new WheeledTransportation(40, 85000);
        objects[2] = new Train(5, 100.0, 10, "Montreal", "Sherbrooke");
        objects[3] = new Train(10, 1000.0, 100, "Ville Quebec", "Trois-Rivere");
        objects[4] = new Tram(9, 16, "Station Pierre Soltaire", "Station Reynasi", 20, 2020, 22);
        objects[5] = new Tram(18, 9, "Station Pierre Sommon", "Station Veyno", 10, 1020, 12);
        objects[6] = new Metro(6, "Levalioni", "Doncurroso", 7, 850.0, 9);
        objects[7] = new Metro(3, "San Persion", "Donselis", 7, 750.0, 6);
        objects[8] = new Monowheel(4, 600, 450);
        objects[9] = new Monowheel(8, 300, 330);
        objects[10] = new Ferry(360, 400);
        objects[11] = new Ferry(290, 430);
        objects[12] = new Aircraft(90000, 14200);
        objects[13] = new Aircraft(450000, 13050);
        objects[14] = new WorldWarIIAiroplane(false, 2200.0, 12000.0);
        objects[15] = new WorldWarIIAiroplane(false, 2300.0, 11000.0);
        objects[16] = new Metro(4, "Quintessa", "Unicron", 2, 850.0, 12);
        
        
        Object[] copiedObjects = copyTheObjects(objects);

        System.out.println(Arrays.toString(copiedObjects));


    }
}