// -----------------------------------------------------
// Assignment 1
// Part: 1
// Written by: (include your name(s) and student ID(s))
// -----------------------------------------------------
package fourthpackage;

import java.util.Objects;

import firstpackage.WheeledTransportation;

public class Monowheel extends WheeledTransportation{

    private double maxWeight;
    private static long nextMonowheelSerialNumber = 55000L;

    public Monowheel() {
        super();
        this.maxWeight = 0.0;
        this.serialNumber = getNextMonowheelSerialNumber();
    }

    public Monowheel(int numOfWheels, double maxSpeed, double maximumWeight) {
        super(numOfWheels, maxSpeed);
        this.maxWeight = maximumWeight;
        this.serialNumber = getNextMonowheelSerialNumber();
    }

    public Monowheel(Monowheel other) {
        super(other);
        this.maxWeight = other.maxWeight;
        this.serialNumber = getNextMonowheelSerialNumber();
    }

    public double getMaxWeight() {
        return maxWeight;
    }

    public static long getNextMonowheelSerialNumber(){
        return nextMonowheelSerialNumber++;
    }

    public void setMaxWeight(double maxWeight){
        this.maxWeight = maxWeight;
    }

    public String toString(){
        return "Monowheel - serial #" + this.serialNumber + " - has " + numOfWheels + " wheels, has a maximum speed of " + maxSpeed +
        " km/hr.  It has a maximum weight of " + maxWeight + " kg.";
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true; // Same object reference, they are equal
        }
    
        if (obj == null || getClass() != obj.getClass()) {
            return false; // Object is null or of a different class, they are not equal
        }
    
        Monowheel otherMonowheel = (Monowheel) obj;
    
        // Compare attributes, excluding the serial number
        return Objects.equals(getNumOfWheels(), otherMonowheel.getNumOfWheels()) &&
               Objects.equals(getMaxSpeed(), otherMonowheel.getMaxSpeed()) &&
               Double.compare(getMaxWeight(), otherMonowheel.getMaxWeight()) == 0;
    }

}