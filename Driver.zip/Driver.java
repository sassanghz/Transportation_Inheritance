import fifthpackage.Aircraft;
import fifthpackage.WorldWarIIAiroplane;
import firstpackage.WheeledTransportation;
import fourthpackage.Monowheel;
import secondpackage.Train;
import secondpackage.Tram;
import sixthpackage.Ferry;
import thirdpackage.Metro;

public class Driver{
    public static void main(String[] args){
        
        WheeledTransportation wt1 = new WheeledTransportation(0, 350);
        WheeledTransportation wt2 = new WheeledTransportation(0, 260);

        Train train1 = new Train(5, 100.0, 10, "Montreal", "Sherbrooke"); 
        Train train2 = new Train(2, 120.0, 5, "Vancouver", "Winnipeg"); 

        Metro metro1 = new Metro(3, "Tusconsicu", "Vedicoro", 3, 350.0, 8);
        Metro metro2 = new Metro(4, "San Delisco", "Donselis", 4, 450.0, 4);

        Tram tram1 = new Tram(3, 4, "Station Pierre Rouge", "Station Qooni", 10, 2010, 10);
        Tram tram2 = new Tram(5, 6, "Station Maxiou", "Station Nino", 8, 2005, 20);

        Monowheel monowheel1 = new Monowheel(2, 200, 450);
        Monowheel monowheel2 = new Monowheel(4, 300, 230);
        
        Ferry f1 = new Ferry(160, 400);
        Ferry f2 = new Ferry(340, 130);
       
        Aircraft ac1 = new Aircraft(30000, 14250);
        Aircraft ac2 = new Aircraft(45000, 13450);
       
        WorldWarIIAiroplane ww2p1 = new WorldWarIIAiroplane(true, 2200.0, 12000.0);
        WorldWarIIAiroplane ww2p2 = new WorldWarIIAiroplane(false, 2300.0, 11000.0);

        System.out.println(wt1.toString());
        System.out.println(wt2.toString());
        System.out.println(train1.toString());
        System.out.println(train2.toString());
        System.out.println(metro1.toString());
        System.out.println(metro2.toString());
        System.out.println(tram1.toString());
        System.out.println(tram2.toString());
        System.out.println(monowheel1.toString());
        System.out.println(monowheel2.toString());
        System.out.println(f1.toString());
        System.out.println(f2.toString());
        System.out.println(ac1.toString());
        System.out.println(ac2.toString());
        System.out.println(ww2p1.toString());
        System.out.println(ww2p2.toString());
        
        System.out.println();
        
        System.out.println( wt1.equals(wt2));
        System.out.println( train1.equals(train2));
        System.out.println( metro1.equals(metro2));
        
        System.out.println();
        
        Object[] array = {wt1, wt2, train1, train2, metro1, metro2, tram1, tram2, monowheel1, monowheel2, f1, f2, ac1, ac2, ww2p1, ww2p2};
        findLeastAndMostExpensiveAircraft(array);

        Object[] array2 = {wt1, wt2, train1, train2, metro1, metro2, tram1, tram2, monowheel1, monowheel2, f1, f2, metro2, tram1, train2, train1};
        findLeastAndMostExpensiveAircraft(array2);
        
    }

    public static void findLeastAndMostExpensiveAircraft(Object[] aircraftArray) {
        Aircraft leastExpensive = null;
        Aircraft mostExpensive = null;

        for (Object obj : aircraftArray) {
            if (obj instanceof Aircraft) {
                Aircraft aircraft = (Aircraft) obj;
                if (leastExpensive == null || aircraft.getPrice() < leastExpensive.getPrice()) {
                    leastExpensive = aircraft;
                }
                if (mostExpensive == null || aircraft.getPrice() > mostExpensive.getPrice()) {
                    mostExpensive = aircraft;
                }
            }
        }

        if (leastExpensive == null && mostExpensive == null) {
            System.out.println("No Aircraft objects found in the array.");
        } else {
            System.out.println("Least Expensive Aircraft:");
            System.out.println(leastExpensive != null ? leastExpensive.toString() : "None found");

            System.out.println("Most Expensive Aircraft:");
            System.out.println(mostExpensive != null ? mostExpensive.toString() : "None found");
        }
    }
}