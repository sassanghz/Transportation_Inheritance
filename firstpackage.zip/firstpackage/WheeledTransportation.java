// -----------------------------------------------------
// Assignment 1
// Part: 1
// Written by: (include your name(s) and student ID(s))
// -----------------------------------------------------
package firstpackage;

public class WheeledTransportation {
    
    protected int numOfWheels;
    protected double maxSpeed;
    protected long serialNumber;

    private static long nextSerialNumber = 0;

    public WheeledTransportation(){
    	this.serialNumber = WheeledTransportation.getserialNumber();
    }

    public WheeledTransportation(int numOfWheels, double maxSpeed){
        this.numOfWheels = numOfWheels;
        this.maxSpeed = maxSpeed;
        this.serialNumber = WheeledTransportation.getserialNumber();
    }

    public WheeledTransportation(WheeledTransportation wheelTransport){
        numOfWheels = wheelTransport.numOfWheels;
        maxSpeed = wheelTransport.maxSpeed;
        this.serialNumber = WheeledTransportation.getserialNumber();

    }

    public int getNumOfWheels(){
        return numOfWheels;
    }

    public double getMaxSpeed(){
        return maxSpeed;
    }

    public static long getserialNumber(){
        return nextSerialNumber++;
    }

    public void setNumOfWheels(int numOfWheels){
        this.numOfWheels = numOfWheels;
    }

    public void setMaxSpeed(double maxSpeed){
        this.maxSpeed = maxSpeed;
    }

    public void setSerialNumber(long serialNumber){
        this.serialNumber = serialNumber;
    }
    
    public static long getNextSerialNumber(){
        return nextSerialNumber;
    }

  
    public String toString(){
        return "Wheeled Transportation - serial #" + this.serialNumber + " - has " + numOfWheels + " wheels, has a maximum speed of " + maxSpeed + " km/hr.";
    }

    public boolean equals(Object obj) {
        // Check if the passed object is null or of a different type
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
    
        // Cast the passed object to WheeledTransportation
        WheeledTransportation other = (WheeledTransportation) obj;
    
        // Compare attributes for equality
        return this.numOfWheels == other.numOfWheels && Double.compare(this.maxSpeed, other.maxSpeed) == 0;
    }

}
