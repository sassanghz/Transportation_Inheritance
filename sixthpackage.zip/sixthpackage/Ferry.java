// -----------------------------------------------------
// Assignment 1
// Part: 1
// Written by: (include your name(s) and student ID(s))
// -----------------------------------------------------
package sixthpackage;

public class Ferry{
    
    private double maximumSpeed;
    private double maximumLoad;
    private long serialNumber; 

    private static long nextFerrySerialNumber = 70000L;

    public Ferry(){
        this.serialNumber = getNextFerrySerialNumber();
    }

    public Ferry(double maxSpeed, double maxWeight){
        this.maximumLoad = maxWeight;
        this.maximumSpeed = maxSpeed;
        this.serialNumber = getNextFerrySerialNumber();
    }

    public Ferry(Ferry max){
        maximumLoad = max.maximumLoad;
        maximumSpeed = max.maximumSpeed;
        this.serialNumber = getNextFerrySerialNumber();
    }

    public static long getNextFerrySerialNumber(){
        return nextFerrySerialNumber++;
    }

    public double getMaximumSpeed(){
        return maximumSpeed;
    }

    public double getMaximumLoad(){
        return maximumLoad;
    }

    public void setMaximumSpeed(double maxSpeed){
        this.maximumSpeed = maxSpeed;
    }

    public void setMaximumLoad(double maxWeight){
        this.maximumLoad = maxWeight;
    }

   public String toString(){
        return "This Ferry - serial #" + this.serialNumber + " - has a maximum speed of " + maximumSpeed + " km/hr. It has a maximum load of " + maximumLoad + " kg.";
   }

   public boolean equals(Object obj) {
    // Check if the object being compared is null
    if (obj == null) {
        return false;
    }

    // Check if the object being compared is of a different type
    if (getClass() != obj.getClass()) {
        return false;
    }

    // Cast the object to a Ferry
    Ferry otherFerry = (Ferry) obj;

    // Compare attributes (maximumSpeed and maximumLoad)
    return Double.compare(getMaximumSpeed(), otherFerry.getMaximumSpeed()) == 0 &&
           Double.compare(getMaximumLoad(), otherFerry.getMaximumLoad()) == 0;
}


}